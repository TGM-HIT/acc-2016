/**
 * Es wird ein Baum mit einer beliebigen Hoehe produziert, gespeichert und in der Konsole ausgegeben.
 * Testklasse f�r Baumfabrik
 * 
 * @author David Maniak
 * @version 07.12.2016
 */
public class TestKlasse {
	public static void main(String[] args) {
		new Control();
	}
}
