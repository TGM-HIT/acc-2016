package main;

/**
 * A program to encode a text
 * 
 * @author Peter Fuchs
 * @version 9 Dec 2016
 */
public class Main {

	/**
	 * main-class to start the program
	 */
	public static void main(String[] args) {
		System.out.println(a("ZPV TPMWFE NZ QVAAMF"));
	}
	
	/**
	 * Encoding method
	 * 
	 * @param d the string to encode
	 * @return the encoded string
	 */
	public static String a (String d) {
		//switch b and c
		String b = "BCDEFGHIJKLMNOPQRSTUVWXYZA";
		String c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String e = "";
		d = d.toUpperCase();
		for (int i = 0; i < d.length(); i++) {
			char f = d.charAt(i);
			if (b.indexOf(f) > -1)
				e += c.charAt(b.indexOf(f));
			else e += f;
		}
		return e;
	}


}
