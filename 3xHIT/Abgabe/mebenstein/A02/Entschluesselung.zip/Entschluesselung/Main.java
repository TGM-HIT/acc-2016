package Entschluesselung;

/**
 * 
 * @author Michael Ebenstein
 * @version 6.12.2016
 * 
 * Result: YOU SOLVED MY PUZZLE
 * Caesar verschluesselung um 2 stellen
 * 
 */

public class Main {

	public static void main(String[] args) {
		String in = "ZPV TPMWFE NZ QVAAMF";
	
		System.out.println(a(in));
	}
	
	public static String a(String d){
		String c = "BCDEFGHIJKLMNOPQRSTUVWXYZA";
		String b = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String e = "";
		d = d.toUpperCase();
		
		for(int i = 0; i < d.length();++i){
			char f = d.charAt(i);
			if(b.indexOf(f) > -1){
				e+=c.charAt(b.indexOf(f));
			}else{
				e+=f;
			}
		}
		
		return e;
	}
	
}
