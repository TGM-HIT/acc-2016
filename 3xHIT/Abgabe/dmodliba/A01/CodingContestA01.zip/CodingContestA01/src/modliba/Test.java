package modliba;

/**
 * Diese Klasse ist ausschlie�lich dazu da, um die korrekte Ausgabe der B�ume zu
 * testen
 * 
 * @author Daniel Modliba
 * @version 06-12-2016
 */
public class Test {

	/**
	 * Die Standard-main Methode des Programms
	 * 
	 * @param args
	 *            Die Argumente des Programms
	 * @since 06-12-2016
	 */
	public static void main(String[] args) {
		Control c = new Control();
	}

}
