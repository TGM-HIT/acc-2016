package modliba;

/**
 * Diese Klasse ver- und entschl�sselt Texte
 * @author Daniel Modliba (3CHIT)
 * @version 06-12-2016
 */
public class Entschl�sselung {

	/**
	 * Standard main-Methode des Programms
	 * 
	 * @param args
	 *            Die Argumente des Programms
	 * @since 06-12-2016
	 * 
	 * *****ERKL�RUNG DER VERSCHL�SSELUNG:*****
	 * 1. Schritt:
	 * 		Jedes Zeichen wird in UpperCase umgewandelt
	 * 2. Schritt:
	 * 		Jedes Zeichen wird durch seinen direkten Nachfolger im Alphabet ersetzt
	 * 		Ausnahmen: 
	 * 			Z -> A (da Z keinen direkten Nachfolger hat)
	 * 			[Sonderzeichen/Zahlen/nicht-Buchstaben] -> [Sonderzeichen/Zahlen/nicht-Buchstaben]
	 * 
	 * Die Entschl�sselung erfolgt nach den selben Regeln allerdings genau umgekehrt
	 * Also jeder Buchstabe wird durch seinen Vorg�nger ersetzt und 'A' wird zu 'Z'
	 */
	public static void main(String[] args) {
		// decodiert den Text aus der Angabe
		System.out.println(decode("ZPV TPMWFE NZ QVAAMF"));

		// Codiert den Text 'You solved my puzzle' um auch die Verschl�sselung
		// zu testen
		System.out.println(a("You solved my puzzle"));
	}

	/**
	 * Decodiert eine Zeichenkette nach dem selben Muster wie die Methode, die
	 * codiert
	 * 
	 * @param coded
	 *            Der String der entschl�sselt werden soll
	 * @return Der entshcl�sselte String
	 * @since 06-12-2016
	 */
	public static String decode(String coded) {
		String code = "BCDEFGHIJKLMNOPQRSTUVWXYZA";
		String key = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String decoded = "";

		coded = coded.toUpperCase();

		for (int i = 0; i < coded.length(); i++) {
			char current = coded.charAt(i);
			if (code.indexOf(current) > -1) {
				decoded += key.charAt(code.indexOf(current));
			} else {
				decoded += current;
			}
		}
		return decoded;
	}

	/**
	 * Diese Methode verschl�sselt eine Zeichenkette und gibt diese anschlie�end
	 * zur�ck
	 * 
	 * @param d
	 *            Die Zeichenkette die verschl�sselt werden soll
	 * @return Die verschl�sselte Zeichenkette
	 * @since 06-12-2016
	 */
	public static String a(String d) {
		// Das Alphabet
		String b = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		// Die zugeh�rigen Buchstaben laut dem Schl�ssel
		String c = "BCDEFGHIJKLMNOPQRSTUVWXYZA";
		// Die verschl�sselte Zeichenkette
		String e = "";

		/*
		 * Hier wird der Eingabe-String in CAPS umgewandelt um die Verggleiche
		 * zu vereinfachen
		 */
		d = d.toUpperCase();

		// Diese Schleife geht den gesamten Eingabe-String durch
		for (int i = 0; i < d.length(); i++) {
			// Das Zeichen an der aktuellen Stelle
			char f = d.charAt(i);

			/*
			 * Wenn f�r das aktuelle Zeichen ein Schl�ssel definiert ist, wird
			 * es verschl�sselt also wenn es im String b enthalten ist (somit
			 * keine Sonderzeichen, Zahlen, etc.)
			 */
			if (b.indexOf(f) > -1) {
				/*
				 * Dem Ausgabe-String wird nun das verschl�sselte Zeichen
				 * hinzugef�gt also das Zeichen, dass sich an der entsprechenden
				 * Stelle im Schl�ssel-String befindet
				 */
				e += c.charAt(b.indexOf(f));

				/*
				 * Wenn f�r das Zeichen kein Schl�ssel definiert ist, wird es
				 * einfach �bernommen
				 */
			} else {
				e += f;
			}
		}
		return e;
	}

}
