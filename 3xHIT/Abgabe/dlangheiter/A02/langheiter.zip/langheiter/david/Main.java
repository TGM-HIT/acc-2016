package langheiter.david;

public class Main {
	
	private static String from = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static String to = "BCDEFGHIJKLMNOPQRSTUVWXYZA";
	
	/**
	 * Prints out secret message
	 * 
	 * @param args Not Used
	 */
	public static void main(String[] args) {
		System.out.println(decrypt("ZPV TPMWFE NZ QVAAMF"));
	}
	
	/**
	 * Function to "encrypt" an message
	 * 
	 * @param in Message to "encrypt"
	 * @return "Encrypted" message
	 */
	static String encrypt(String in) {
		String ret = "";
		in = in.toUpperCase();
		for(int i=0; i < in.length(); i++) {
			char f = in.charAt(i);
			if(to.indexOf(f)>-1) {
				ret += to.charAt(from.indexOf(f));
			} else {
				ret+=f;
			}
		}
		return ret;
	}
	
	/**
	 * Function to "decrypts" an message
	 * 
	 * @param in Encrypted message to decrypt
	 * @return Decrypted message
	 */
	static String decrypt(String in) {
		String ret = "";
		in = in.toUpperCase();
		for(int i=0; i < in.length(); i++) {
			char f = in.charAt(i);
			if(to.indexOf(f)>-1) {
				ret += from.charAt(to.indexOf(f));
			} else {
				ret+=f;
			}
		}
		return ret;
	}
	
}
