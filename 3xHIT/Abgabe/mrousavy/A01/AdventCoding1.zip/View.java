/**
 * Created by b4dpi on 06.12.2016.
 */
public class View {

    public void drawTree(String tree){
        System.out.println(tree);
    }
}
