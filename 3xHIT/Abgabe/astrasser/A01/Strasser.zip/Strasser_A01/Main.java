package Strasser_A01;

/**
 * Starts the application by creating a new instance of the Control class
 * 
 * @author Alexander Strasser
 * @version 2016-12-06
 *
 */
public class Main {
	public static void main(String[] args) {
		new Control();
	}
}
