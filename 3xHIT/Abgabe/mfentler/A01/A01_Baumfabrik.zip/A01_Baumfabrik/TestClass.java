package A01_Baumfabrik;

/**
 * Testklasse
 * 
 * @author mario fentler
 * @version 06.12.2016
 */
public class TestClass {
	public static void main(String[] args) {
		new Control();
	}
}
