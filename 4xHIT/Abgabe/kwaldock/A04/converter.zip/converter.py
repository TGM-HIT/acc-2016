import io

from server import Server


class MDHTMLConverter:
    @staticmethod
    def convert(source, filetype="html"):
        # Basename --> "test.md" --> "test"
        basename = source
        optional_dot_index = basename.find(".")
        if optional_dot_index != -1:
            basename = basename[0:optional_dot_index]

        # Read the source md file
        lines = None
        with io.open(source, "r") as source_file:
            lines = source_file.readlines()

        # Conversion Code
        out_lines = []
        is_in_list = False
        for line in lines:
            # Need this bool to continue out of the inner loop
            parse_line_finished = False
            # Possible title
            for heading_layer in range(4, 0, -1):  # from 4 to 1 inclusive
                if line.startswith('#' * heading_layer):
                    out_lines.append("<h%d>%s</h%d>" % (heading_layer, line[heading_layer:len(line)], heading_layer))
                    parse_line_finished = True
                    break

            if parse_line_finished:
                continue

            # Possible lists
            if line.startswith("* ") or line.startswith("- "):
                if not is_in_list:
                    out_lines.append("<ul>")
                    is_in_list = True
                out_lines.append("<li>%s</li>" % line[2:len(line)])
                continue
            else:
                if is_in_list:
                    out_lines.append("</ul>")
                    is_in_list = False

            # Possible bold
            if line.startswith("*") and line.endswith("*"):
                out_lines.append("<b>%s</b>" % line[1:len(line) - 1])
                continue

            # No markup to apply --> Add source line
            out_lines.append(line)

        # Write result
        with io.open(basename + "." + filetype, "w") as out_file:
            out_file.writelines(out_lines)





if __name__ == "__main__":
    server = Server()
    MDHTMLConverter.convert("test.md")

    server.start()
