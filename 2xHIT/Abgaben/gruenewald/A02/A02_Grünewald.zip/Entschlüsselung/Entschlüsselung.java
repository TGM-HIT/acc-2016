
/**
 * Aufgabe A02 --> Entschlüsselung
 * @author Sebastian Grünewald 2DHIT
 * @version 08-12-2016
 */
public class Entschlüsselung
{
    public static String Stringa(String d){
        //LÖSUNG: Vertauschung der String-Ketten

        String c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";  //String c war vorher String b
        String b = "BCDEFGHIJKLMNOPQRSTUVWXYZA";  //String b war vorher String c
        String e = "";

        d = d.toUpperCase();

        for(int i = 0; i < d.length(); i++){
            char f = d.charAt(i);
            if(b.indexOf(f) > -1){
                e += c.charAt(b.indexOf(f));
            }
            else{
                e += f;
            }
        }

        return e;
    }

    public static void main (String[] args) {
        String d = Stringa("ZPV TPMWFE NZ QVAAMF");
        System.out.println(d);
    }
}
