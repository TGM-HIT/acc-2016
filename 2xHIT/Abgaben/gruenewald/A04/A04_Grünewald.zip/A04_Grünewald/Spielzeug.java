
/**
 * A04 --> Spielzeuglade
 * @author Sebastian Grünewald 2DHIT 
 * @version 8-12-2016
 */
public class Spielzeug
{
    private String name;
    private int minAlter;
    private int maxAlter;
    
    public Spielzeug (Spielzeug[] liste, String name, int min, int max) {
        this.name = name;
        this.minAlter = min;
        this.maxAlter = max;
        
        for (int i = 0; i < liste.length; i++) {
            liste[i] = add(this);
        }
        
        print();
    }
    
    public Spielzeug add (Spielzeug s) {
        return s;
    }
    
    public void print() {
        System.out.println("Name: "+this.name);
        System.out.println("Mindestalter: "+this.minAlter);
        System.out.println("Alterslimit: "+this.maxAlter+"\n-----------------------------------------------------------------");
    }
    
    public static void main (String[] args) {
        Spielzeug[] liste = new Spielzeug[5];
        
        Spielzeug s1 = new Spielzeug(liste,"Auto",5,15);
        Spielzeug s2 = new Spielzeug(liste,"Handy",10,75);
        Spielzeug s3 = new Spielzeug(liste,"Computer",13,75);
        Spielzeug s4 = new Spielzeug(liste,"Lego",5,80);
        Spielzeug s5 = new Spielzeug(liste,"Mensch-Ärgere-Dich-Nicht",5,90);
    }
}
