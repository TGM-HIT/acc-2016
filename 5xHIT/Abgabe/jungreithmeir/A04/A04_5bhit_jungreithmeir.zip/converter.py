from server import Server

import re


class MDHTMLConverter:
    """
    author: Jakob Jungreithmeir
    version: 08-12-2016

    Converts a given markdown file into a basic html file. There are tons of libraries which already
    offer this, but I decided to write my own implementation, because why not.
    """

    @staticmethod
    def convert(source, filetype="html"):
        """
        Parses the markdown with simple regex checks. Some of them could have been solved with
        python string methods, but I wanted to keep it consistent, so I used re for all of them.

        :param source: name of the source file
        :param filetype:
        """
        markdown = open(source).read().splitlines()
        b = HTMLBuilder()

        for line in markdown:
            if re.search("(?<=^# )[a-zA-Z]+", line, re.M | re.I): # '# asdf'
                b.h1(re.search("(?<=# )[a-zA-Z]+", line, re.M | re.I).group(0))
            elif re.search("(?<=^## )[a-zA-Z]+", line, re.M | re.I): # '## asdf'
                b.h2(re.search("(?<=## )[a-zA-Z]+", line, re.M | re.I).group(0))
            elif re.search("(?<=^### )[a-zA-Z]+", line, re.M | re.I): # '### asdf'
                b.h3(re.search("(?<=### )[a-zA-Z]+", line, re.M | re.I).group(0))
            elif re.search("(?<=^#### )[a-zA-Z]+", line, re.M | re.I): # '#### asdf'
                b.h4(re.search("(?<=#### )[a-zA-Z]+", line, re.M | re.I).group(0))
            elif re.search("(?<=^(\*|-) )[a-zA-Z]+", line, re.M | re.I): # '- asdf' or '* asdf'
                b.li(re.search("(?<=^(\*|-) )[a-zA-Z]+", line, re.M | re.I).group(0))
            elif re.search("^$", line, re.M | re.I): # '\n'
                b.br()
            elif re.search("(?<=\*).*(?=\*)", line, re.M | re.I): # '*asdf*'
                b.b(re.search("(?<=\*).*(?=\*)", line, re.M | re.I).group(0))
            else: # 'asdf'
                b.p(line)

        b.write(source.replace('.md', ''))


class HTMLBuilder(object):
    """
    author: Jakob Jungreithmeir
    version: 08-12-2016

    Builds simple html files upon request. There are also tons of libraries which already do this,
    but using my own was more convenient, mainly because I need to build the file on the go,
    while reading the markdown file.
    This whole class is pointer-based, that means the new content is always inserted after
    the previously inserted content.
    I have not documented all of the methods, as there names are self-explanatory. Generally
    speaking the text parameter should contain the text to be inserted in the tags.
    """

    def __init__(self):
        """
        Creates the basic html structure. Sets the editing pointer to the body.
        """
        self.html = ['<!DOCTYPE html>',
                     '<html>',
                     '<head>',
                     '</head>',
                     '<body>',
                     '</body>',
                     '</html>']
        self.pointer = 0
        self.list_processing = False
        self.edit_body()

    def edit_head(self):
        """
        Sets the pointer to the inner end of the head.
        """
        self.pointer = self.html.index('</head>')

    def edit_body(self):
        """
        Sets the pointer to the inner end of the body.
        """
        self.pointer = self.html.index('</body>')

    def h1(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<h1>' + text + '</h1>')
        self.pointer += 1

    def h2(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<h2>' + text + '</h2>')
        self.pointer += 1

    def h3(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<h3>' + text + '</h3>')
        self.pointer += 1

    def h4(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<h4>' + text + '</h4>')
        self.pointer += 1

    def p(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<p>' + text + '</p>')
        self.pointer += 1

    def br(self):
        self.__end_list()
        self.html.insert(self.pointer, '<br/>')
        self.pointer += 1

    def b(self, text):
        self.__end_list()
        self.html.insert(self.pointer, '<b>' + text + '</b>')
        self.pointer += 1

    def li(self, text):
        """
        If you want to build a list, do not worry about the <ul> tag, it is automatically opened
        and closed before and after the <li> usage.
        :param text:
        """
        if not self.list_processing:
            self.html.insert(self.pointer, '<ul>')
            self.pointer += 1
            self.list_processing = True
        self.html.insert(self.pointer, '<li>' + text + '</li>')
        self.pointer += 1

    def __end_list(self):
        """
        Checks if the builder is currently in list mode. This is only called from non list methods,
        that means if it is in list mode, the list tag is closed.
        """
        if self.list_processing:
            self.html.insert(self.pointer, '</ul>')
            self.pointer += 1
            self.list_processing = False

    def write(self, file_name):
        """
        Writes the built html structure to a file. Currently no indentation is supported.
        :param file_name: Name of the new file (no ending!)
        """
        with open(file_name + '.html', 'w') as f:
            for line in self.html:
                f.write(line + '\n')


if __name__ == "__main__":
    server = Server()
    MDHTMLConverter.convert("test.md")

    server.start()
