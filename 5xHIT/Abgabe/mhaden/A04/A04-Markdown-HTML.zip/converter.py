from server import Server


class MDHTMLConverter:
    @staticmethod
    def convert(source, filetype="html"):
        origin = open(source)
        target = open("index." + filetype, "w")

        out = ""

        for line in origin:
            if line[:4] == "####":
                out += "<h4>" + line[5:len(line) - 1] + "</h4>\n"
            elif line[:3] == "###":
                out += "<h3>" + line[4:len(line) - 1] + "</h3>\n"
            elif line[:2] == "##":
                out += "<h2>" + line[3:len(line) - 1] + "</h2>\n"
            elif line[:1] == "#":
                out += "<h1>" + line[2:len(line) - 1] + "</h1>\n"
            elif line[:1] == "-":
                out += "<li>" + line[2:len(line) - 1] + "</li>\n"
            elif line[:1] == "*" and line[len(line) - 1:] == "*":
                out += "<b>" + line[1:len(line) - 1] + "</b>"
            elif line[:1] == "*":
                out += "<li>" + line[2:len(line) - 1] + "</li>\n"
            else:
                out += line[:len(line) - 1] + "<br>\n"

        target.write(out)
        target.close()


if __name__ == "__main__":
    server = Server()
    MDHTMLConverter.convert("test.md")

    server.start()
