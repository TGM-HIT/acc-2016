import requests
from html.parser import HTMLParser
from urllib.parse import urlparse
from threading import Thread


class Crawler:
    """
    gets websites
    """
    link_list = []

    def __init__(self, site):
        thread = Thread(target=Parser, args=(site, 1, self.get_page(site)))
        thread.start()
        thread.join()

        self.print_list()

    def get_page(self, site):
        '''
        downloads website

        :param site: site to get
        :return: sourcecode
        '''
        page = requests.get(site).text

        return page

    def print_list(self):
        '''
            prints all links and writes them into file
        '''
        f = open('links.txt', 'w')

        print("### Anzahl Links: %s ###" % len(self.link_list))
        for item in self.link_list:
            f.write(item + "\n")


class Parser(HTMLParser):
    '''
    parses the website code
    '''
    thread_pool = []

    def __init__(self, site, ttl, page):
        super().__init__()
        self.site = site
        self.ttl = ttl
        self.feed(page)

    def handle_starttag(self, tag, attrs):
        '''
        is called when a starttag occurs

        :param tag: the starttag
        :param attrs: the attributes
        '''
        if tag == "a" and attrs[0][0] == "href":
            if attrs[0][1][:1] == "/":
                url = self.site + attrs[0][1]
                if url not in Crawler.link_list:
                    Crawler.link_list.append(url)
                if self.ttl > 0:
                    self.thread_pool.append(Thread(target=Parser,
                                                   args=(self.site, self.ttl - 1,
                                                         Crawler.get_page(Crawler, self.site + attrs[0][1]))))
                    self.thread_pool[len(self.thread_pool) - 1].start()
                    self.thread_pool[len(self.thread_pool) - 1].join()
            elif attrs[0][1][:4] in ("http", "www."):
                if attrs[0][1] not in Crawler.link_list:
                    Crawler.link_list.append(attrs[0][1])
                if self.ttl > 0:
                    self.thread_pool.append(Thread(target=Parser,
                                                   args=(urlparse(attrs[0][1]).scheme + "://" +
                                                         urlparse(attrs[0][1]).netloc, self.ttl - 1,
                                                         Crawler.get_page(Crawler, attrs[0][1]))))
                    self.thread_pool[len(self.thread_pool) - 1].start()
                    self.thread_pool[len(self.thread_pool) - 1].join()


if __name__ == '__main__':
    Crawler("https://github.com")
